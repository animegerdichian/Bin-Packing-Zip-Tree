#include "project2.h"
#include <iostream>
#include <algorithm>
#include <cstdint>
#include <cmath>
#include <cfloat>
#include <climits>
#include <initializer_list>

#include "ZipTree.h"


bool equal(double x, double y){
   return std::fabs(x - y) <= 1e-10;

}

void updateBins(node<double,int>* node, std::vector<double>& free_space){
    if (node == nullptr){
            return;
    }
    updateBins(node->left, free_space);
    free_space[node->value - 1] = node->key;
    updateBins(node->right, free_space);
}

void traverse(node<double, int>* n,double x,bool& flag,double& newKey,int& binNum){

    if(n == nullptr || flag == true){
        return;
    }

    traverse(n->left,x,flag,newKey,binNum);

    if((n->key >= (x - 1e-6) || std::fabs(x - n->key) < 1e-6) && flag != true){

        newKey = n->key;
        binNum = n->value;
        flag = true;
        return;
    }
    traverse(n->right,x,flag,newKey,binNum);
}



void best_fit(const std::vector<double>& items, std::vector<int>& assignment, std::vector<double>& free_space){
    // rank = randomly generated, key = remaining capacity, value = (bin index)
        // A FUNCTION TO CHECK BRC EVERY TIME THERE'S AN INSERT
    /*
        ZipTree<double, int> tree;
        int total_bins = 0;
        node<double, int>* treeRoot = tree.getRoot();
        for(int i=0; i < items.size(); i++){

            if(i == 0 || tree.getSize() == 0){
                // create the first bin
                tree.insert(1-items[i],i+1);
                assignment[i] = 1;// update assignments
                free_space.push_back(0.0);
                total_bins += 1;
            }
            else{
                treeRoot = tree.getRoot();
                double newKey = -1.0;
                int binNum = -1;
                bool flag = false;
                traverse(treeRoot,items[i],flag,newKey,binNum);

                if(flag == true){ // bin to put item is found
                    tree.remove(newKey); // remove the bin

                    double new_capacity = newKey - items[i]; // calculate new capacity

                    assignment[i] = binNum; // assign item to bin
                    if(!equal(new_capacity, 0.0)){ // if capacity is 0
                        tree.insert(new_capacity, binNum);
                        free_space[binNum - 1] = 0.0;
                    }

                }
                else{
                    tree.insert(1-items[i],total_bins + 1);
                    assignment[i] = total_bins + 1;
                    total_bins += 1;
                    free_space.push_back(0.0);



                }

            }


        }

        treeRoot = tree.getRoot();

        updateBins(treeRoot, free_space);
*/
    return;
}
void best_fit_decreasing(const std::vector<double>& items, std::vector<int>& assignment, std::vector<double>& free_space){
    return;
}
