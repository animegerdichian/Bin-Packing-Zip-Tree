#include "project2.h"

void best_fit(const std::vector<double>& items, std::vector<int>& assignment, std::vector<double>& free_space){
    return;
}
void best_fit_decreasing(const std::vector<double>& items, std::vector<int>& assignment, std::vector<double>& free_space){
    return;
}
